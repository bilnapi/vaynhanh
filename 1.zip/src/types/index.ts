export interface LoanPartner {
  id: string;
  name: string;
  officialUrl: string;
  logo: string;
  tagline: string;
  badge: string;
  minAmount: number;
  maxAmount: number;
  minTermDays: number;
  maxTermDays: number;
  interestRateText: string;
  firstLoanPromo: string;
  approvalSpeed: string;
  approvalRatePercent: number;
  rating: number;
  reviewCount: number;
  badDebtSupport: string; // e.g. "Hỗ trợ nợ xấu nhóm 1, 2, 3"
  features: string[];
  themeColor: {
    bg: string;
    border: string;
    text: string;
    btn: string;
    btnHover: string;
    lightBg: string;
  };
}

export interface AmortizationMonth {
  month: number;
  payment: number;
  principalPortion: number;
  interestPortion: number;
  remainingBalance: number;
}

export interface LoanCalculationResult {
  principal: number;
  months: number;
  annualInterestRate: number;
  monthlyPayment: number;
  totalPayment: number;
  totalInterest: number;
  isFirstLoanPromo: boolean;
  schedule: AmortizationMonth[];
}

export type ApplicationStatus = 'submitted' | 'cic_review' | 'partner_matching' | 'approved' | 'disbursed';

export interface ApplicationRecord {
  id: string;
  fullName: string;
  phone: string;
  cccd: string;
  amount: number;
  termMonths: number;
  badDebtGroup: string;
  partnerId: string;
  partnerName: string;
  status: ApplicationStatus;
  createdAt: string;
  updatedAt: string;
  email?: string;
  bankAccount?: string;
  bankName?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  quickAction?: {
    partnerId: string;
    link: string;
    label: string;
  };
}
