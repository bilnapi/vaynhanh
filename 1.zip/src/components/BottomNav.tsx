import React from 'react';
import { Layers, Calculator, FileCheck2, FileSearch, MessageSquareText } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openChatbot: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab, openChatbot }) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 shadow-lg shadow-slate-900/10">
      <div className="grid grid-cols-5 gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('loans')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'loans' ? 'text-blue-600 font-extrabold' : 'text-slate-500 font-medium hover:text-slate-800'
          }`}
        >
          <Layers className={`w-5 h-5 ${activeTab === 'loans' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">Gói Vay</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('calculator')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'calculator' ? 'text-blue-600 font-extrabold' : 'text-slate-500 font-medium hover:text-slate-800'
          }`}
        >
          <Calculator className={`w-5 h-5 ${activeTab === 'calculator' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">Tính Lãi</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('apply')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'apply' ? 'text-blue-600 font-extrabold' : 'text-slate-500 font-medium hover:text-slate-800'
          }`}
        >
          <FileCheck2 className={`w-5 h-5 ${activeTab === 'apply' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">Đăng Ký</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('tracking')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'tracking' ? 'text-blue-600 font-extrabold' : 'text-slate-500 font-medium hover:text-slate-800'
          }`}
        >
          <FileSearch className={`w-5 h-5 ${activeTab === 'tracking' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">Tra Cứu</span>
        </button>

        <button
          type="button"
          onClick={openChatbot}
          className="flex flex-col items-center justify-center py-1 rounded-xl text-indigo-600 font-bold hover:text-indigo-800 transition-all cursor-pointer relative"
        >
          <div className="relative">
            <MessageSquareText className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500" />
          </div>
          <span className="text-[10px] mt-0.5">Tư Vấn 24/7</span>
        </button>
      </div>
    </div>
  );
};
