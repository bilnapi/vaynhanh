import React from 'react';
import { X, ShieldCheck, AlertTriangle, CheckCircle2, ExternalLink } from 'lucide-react';
import { CIC_DEBT_GROUPS, LOAN_PARTNERS } from '../data/partners';

interface CICGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CICGuideModal: React.FC<CICGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-slate-900 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white">Cẩm Nang Nợ Xấu CIC & Cơ Hội Vay Vốn</h3>
              <p className="text-xs text-slate-300">Phân loại 5 nhóm nợ CIC và tỷ lệ phê duyệt</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-slate-700 text-xs sm:text-sm">
          <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs">
            <strong className="font-bold">CIC (Trung tâm Thông tin Tín dụng Quốc gia)</strong> là nơi lưu trữ lịch sử vay vốn của bạn. Khi quá hạn trả nợ, hệ thống sẽ xếp vào các nhóm 1 đến 5. Tuy nhiên, các tổ chức FinTech như <strong>MoneyCat, Vay VND, Jeff, Money Veo</strong> áp dụng thuật toán chấm điểm độc lập nên vẫn hỗ trợ giải ngân!
          </div>

          <div className="space-y-3">
            <h4 className="font-extrabold text-slate-900 uppercase text-xs tracking-wider">
              Bảng tra cứu 5 nhóm nợ CIC:
            </h4>

            {CIC_DEBT_GROUPS.map((item) => (
              <div
                key={item.group}
                className="p-3.5 rounded-xl border border-slate-200 hover:border-blue-400 transition-colors bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900">{item.title}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{item.desc}</p>
                </div>
                <div className="shrink-0 flex items-center gap-1.5 bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-lg border border-emerald-200 text-xs font-bold self-start sm:self-center">
                  <span>Tỷ lệ duyệt:</span>
                  <strong>{item.rate}</strong>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">
              3 Mẹo để được duyệt hồ sơ ngay lập tức:
            </h4>
            <div className="space-y-1.5 text-xs text-slate-600">
              <p>1. <strong>Sử dụng SIM chính chủ:</strong> SIM Viettel, Vinaphone hoặc Mobifone đã dùng trên 6 tháng có điểm tín dụng cao hơn 40%.</p>
              <p>2. <strong>Khai báo thu nhập ổn định:</strong> Nhập mức thu nhập từ 5.000.000đ - 8.000.000đ/tháng (không yêu cầu chứng minh sao kê).</p>
              <p>3. <strong>Đăng ký cùng lúc:</strong> Nếu nợ xấu nhóm 3 trở lên, nên đăng ký cả <strong>Jeff</strong> và <strong>MoneyCat</strong> để hệ thống ghép nối tối ưu.</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer transition-colors"
          >
            Đã hiểu, quay lại chọn gói vay
          </button>
        </div>
      </div>
    </div>
  );
};
