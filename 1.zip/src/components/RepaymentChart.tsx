import React, { useState } from 'react';
import { BarChart3, TrendingDown, Calendar, CheckCircle2, ChevronDown, ChevronUp, AlertCircle, Sparkles } from 'lucide-react';
import { LoanCalculationResult } from '../types';
import { formatVND } from '../utils/calculator';

interface RepaymentChartProps {
  calculation: LoanCalculationResult;
  onApplyForLoan?: () => void;
}

export const RepaymentChart: React.FC<RepaymentChartProps> = ({ calculation, onApplyForLoan }) => {
  const [selectedMonth, setSelectedMonth] = useState<number | null>(1);
  const [showFullTable, setShowFullTable] = useState(false);

  const { schedule, principal, months, totalInterest, totalPayment, isFirstLoanPromo } = calculation;

  if (!schedule || schedule.length === 0) {
    return null;
  }

  const activeScheduleItem = schedule.find((item) => item.month === selectedMonth) || schedule[0];
  const maxPayment = Math.max(...schedule.map((item) => item.payment), 1);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-6 space-y-6">
      {/* Title & Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-extrabold text-slate-900">
              Biểu Đồ Trực Quan Hóa Tiến Độ Trả Nợ Hàng Tháng
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Theo dõi sự giảm dần của dư nợ và tỷ lệ Gốc - Lãi theo từng kỳ để lập kế hoạch tài chính cá nhân an toàn.
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-blue-600" />
            <span className="text-slate-600 font-medium">Tiền gốc</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-amber-500" />
            <span className="text-slate-600 font-medium">Tiền lãi</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-500" />
            <span className="text-slate-600 font-medium">Dư nợ còn lại</span>
          </div>
        </div>
      </div>

      {/* Visual Bar Chart */}
      <div className="space-y-2">
        <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex justify-between">
          <span>Tiến độ từng kỳ thanh toán (Bấm vào cột để xem chi tiết kỳ đó)</span>
          <span>{months} Tháng</span>
        </div>

        {/* Chart Canvas / Interactive SVG Bars */}
        <div className="h-48 sm:h-56 w-full flex items-end gap-1.5 sm:gap-2.5 pt-8 pb-2 px-2 bg-slate-50/80 rounded-xl border border-slate-200/60 overflow-x-auto scrollbar-none">
          {schedule.map((item) => {
            const isSelected = selectedMonth === item.month;
            const principalHeight = Math.round((item.principalPortion / maxPayment) * 80);
            const interestHeight = Math.round((item.interestPortion / maxPayment) * 80);
            const remainingPercent = Math.round((item.remainingBalance / principal) * 100);

            return (
              <button
                key={item.month}
                type="button"
                onClick={() => setSelectedMonth(item.month)}
                className={`flex-1 min-w-[38px] flex flex-col items-center justify-end h-full group cursor-pointer focus:outline-hidden transition-all ${
                  isSelected ? 'opacity-100 scale-102' : 'opacity-85 hover:opacity-100'
                }`}
              >
                {/* Remaining debt indicator bubble */}
                <div
                  className={`text-[9px] font-bold px-1 py-0.5 rounded-sm mb-1 transition-colors ${
                    isSelected ? 'bg-indigo-600 text-white' : 'text-slate-400 group-hover:text-slate-700'
                  }`}
                >
                  {remainingPercent}%
                </div>

                {/* Stacked Bar */}
                <div className={`w-full max-w-[28px] rounded-t-md overflow-hidden flex flex-col justify-end transition-all ${
                  isSelected ? 'ring-2 ring-indigo-500 shadow-md' : ''
                }`}>
                  {/* Interest bar segment */}
                  {interestHeight > 0 && (
                    <div
                      style={{ height: `${interestHeight}%` }}
                      className="w-full bg-amber-400 group-hover:bg-amber-500 transition-colors"
                      title={`Lãi kỳ ${item.month}: ${formatVND(item.interestPortion)}`}
                    />
                  )}
                  {/* Principal bar segment */}
                  <div
                    style={{ height: `${Math.max(principalHeight, 8)}%` }}
                    className={`w-full ${
                      isSelected ? 'bg-blue-600' : 'bg-blue-500 group-hover:bg-blue-600'
                    } transition-colors`}
                    title={`Gốc kỳ ${item.month}: ${formatVND(item.principalPortion)}`}
                  />
                </div>

                {/* Month Label */}
                <span className={`text-[11px] font-bold mt-2 ${
                  isSelected ? 'text-indigo-600 underline font-extrabold' : 'text-slate-500'
                }`}>
                  T{item.month}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Month Detail Card */}
      {activeScheduleItem && (
        <div className="bg-indigo-50/70 border border-indigo-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white font-extrabold flex items-center justify-center text-sm shadow-xs">
              T{activeScheduleItem.month}
            </div>
            <div>
              <span className="text-xs font-bold text-indigo-900 block">
                Chi Tiết Kỳ Trả Nợ Thứ {activeScheduleItem.month} (Tháng {activeScheduleItem.month})
              </span>
              <span className="text-xs text-indigo-700">
                Dư nợ gốc còn lại sau kỳ này: <strong className="font-extrabold">{formatVND(activeScheduleItem.remainingBalance)}</strong>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <div className="text-right">
              <span className="text-slate-500 block text-[10px] uppercase">Gốc kỳ này</span>
              <span className="text-blue-700 font-bold">{formatVND(activeScheduleItem.principalPortion)}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block text-[10px] uppercase">Lãi kỳ này</span>
              <span className="text-amber-700 font-bold">{formatVND(activeScheduleItem.interestPortion)}</span>
            </div>
            <div className="text-right pl-3 border-l border-indigo-200">
              <span className="text-slate-500 block text-[10px] uppercase">Tổng thanh toán</span>
              <span className="text-indigo-900 font-extrabold text-sm">{formatVND(activeScheduleItem.payment)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Full Amortization Table */}
      <div className="border-t border-slate-100 pt-3">
        <button
          type="button"
          onClick={() => setShowFullTable(!showFullTable)}
          className="w-full py-2 flex items-center justify-center gap-1.5 text-xs font-bold text-slate-700 hover:text-blue-600 transition-colors cursor-pointer"
        >
          <span>{showFullTable ? 'Thu gọn bảng lịch trả nợ' : 'Xem toàn bộ bảng lịch thanh toán chi tiết từng tháng'}</span>
          {showFullTable ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {showFullTable && (
          <div className="mt-3 overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-600 uppercase font-bold text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Kỳ (Tháng)</th>
                  <th className="py-2.5 px-3 text-right">Số tiền trả kỳ này</th>
                  <th className="py-2.5 px-3 text-right">Tiền gốc</th>
                  <th className="py-2.5 px-3 text-right">Tiền lãi</th>
                  <th className="py-2.5 px-3 text-right">Dư nợ còn lại</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {schedule.map((row) => (
                  <tr
                    key={row.month}
                    className={`hover:bg-blue-50/50 transition-colors ${
                      selectedMonth === row.month ? 'bg-indigo-50/60 font-semibold' : ''
                    }`}
                  >
                    <td className="py-2 px-3 font-bold text-slate-900">Tháng {row.month}</td>
                    <td className="py-2 px-3 text-right font-extrabold text-blue-700">{formatVND(row.payment)}</td>
                    <td className="py-2 px-3 text-right">{formatVND(row.principalPortion)}</td>
                    <td className="py-2 px-3 text-right text-amber-700">{formatVND(row.interestPortion)}</td>
                    <td className="py-2 px-3 text-right font-medium">{formatVND(row.remainingBalance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Credit Repair Tip Notice */}
      <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-start gap-2.5">
        <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <strong className="font-bold">Bí quyết xóa nợ xấu CIC:</strong> Thanh toán đúng hạn từng kỳ theo biểu đồ trên không những giúp bạn không bị phạt phí trễ hạn mà còn giúp hệ thống tự động ghi nhận điểm tín dụng tốt, giúp hồ sơ nâng hạn mức lên tới 30 - 50 triệu cho những lần vay sau!
        </div>
      </div>
    </div>
  );
};
