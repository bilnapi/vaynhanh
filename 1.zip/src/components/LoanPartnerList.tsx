import React, { useState } from 'react';
import { 
  ExternalLink, CheckCircle, Clock, Zap, Star, Shield, ArrowRight, 
  Sparkles, Table, LayoutGrid, Check, Percent, Smartphone, Award
} from 'lucide-react';
import { LOAN_PARTNERS } from '../data/partners';
import { LoanPartner } from '../types';
import { formatVND } from '../utils/calculator';

interface LoanPartnerListProps {
  onSelectPartnerForApply?: (partner: LoanPartner) => void;
}

export const LoanPartnerList: React.FC<LoanPartnerListProps> = ({ onSelectPartnerForApply }) => {
  const [filter, setFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  const filteredPartners = LOAN_PARTNERS.filter((partner) => {
    if (filter === 'all') return true;
    if (filter === 'promo') return partner.firstLoanPromo.includes('0%');
    if (filter === 'heavy_bad_debt') return partner.badDebtSupport.includes('4') || partner.badDebtSupport.includes('5') || partner.badDebtSupport.includes('3');
    if (filter === 'fastest') return partner.approvalSpeed.includes('3') || partner.approvalSpeed.includes('5');
    if (filter === 'high_amount') return partner.maxAmount >= 15000000;
    return true;
  });

  return (
    <section id="loans-section" className="py-8 px-3 sm:px-6 max-w-7xl mx-auto space-y-6">
      {/* Section Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-linear-to-r from-blue-600 to-indigo-600 text-white text-xs font-black tracking-wide shadow-sm">
              <Zap className="w-4 h-4 fill-amber-300 text-amber-300 animate-pulse" />
              <span>BẢNG DANH SÁCH DUYỆT CẤP TỐC TRONG 5 PHÚT</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
              Bảng So Sánh Các Khoản Vay Hỗ Trợ Nợ Xấu
            </h2>
            <p className="text-slate-600 text-sm sm:text-base font-medium max-w-2xl">
              Danh sách hiển thị to rõ, đầy đủ thông tin hạn mức, thời gian duyệt và link đăng ký trực tiếp của 4 đối tác: <strong className="text-slate-900">MoneyCat, Vay VND, Jeff, Money Veo</strong>.
            </p>
          </div>

          {/* Quick Stats Banner */}
          <div className="bg-linear-to-br from-amber-500/10 via-amber-500/5 to-emerald-500/10 border-2 border-amber-300/80 rounded-2xl p-4 sm:p-5 flex items-center gap-4 shrink-0">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-black text-xl shadow-md shrink-0">
              ⚡
            </div>
            <div>
              <div className="text-xs uppercase font-extrabold tracking-wider text-amber-900">
                Tỷ Lệ Giải Ngân Trung Bình
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900">
                98.5% <span className="text-xs text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded-md">Duyệt 24/7</span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">Tiền về tài khoản ATM trong 5 - 15 phút</p>
            </div>
          </div>
        </div>

        {/* View mode toggle & Filter row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-6 pt-6 border-t border-slate-100">
          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                filter === 'all'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Tất cả 4 đối tác
            </button>
            <button
              onClick={() => setFilter('promo')}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                filter === 'promo'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🎁 0% Lãi suất lần đầu
            </button>
            <button
              onClick={() => setFilter('heavy_bad_debt')}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                filter === 'heavy_bad_debt'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-500/20'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🛡️ Nợ xấu nhóm 3, 4, 5
            </button>
            <button
              onClick={() => setFilter('fastest')}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                filter === 'fastest'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              ⚡ Duyệt 3 - 5 phút
            </button>
            <button
              onClick={() => setFilter('high_amount')}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                filter === 'high_amount'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              💰 Hạn mức đến 30 Triệu
            </button>
          </div>

          {/* Toggle View Mode (Table vs Large Cards) */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl self-end sm:self-auto shrink-0">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Table className="w-4 h-4" />
              <span>Dạng Bảng To</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              <span>Dạng Thẻ Lớn</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: PROMINENT COMPARISON TABLE (DẠNG BẢNG TO) */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-3xl border-2 border-slate-200 shadow-xl overflow-hidden">
          {/* Scroll instruction for mobile */}
          <div className="md:hidden bg-blue-50 px-4 py-2 text-xs text-blue-700 font-semibold flex items-center justify-between border-b border-blue-100">
            <span>👉 Kéo ngang bảng để xem đầy đủ cột so sánh</span>
            <span className="text-[10px] bg-blue-200 px-2 py-0.5 rounded-md font-bold">4 ĐỐI TÁC</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[850px] lg:min-w-full">
              {/* Table Header */}
              <thead>
                <tr className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 text-white text-xs sm:text-sm uppercase font-black tracking-wider">
                  <th className="py-4 px-5 text-left w-[24%]">Đơn Vị Cho Vay</th>
                  <th className="py-4 px-4 text-left w-[18%]">Hạn Mức Vay</th>
                  <th className="py-4 px-4 text-left w-[14%]">Thời Gian Duyệt</th>
                  <th className="py-4 px-4 text-left w-[18%]">Lãi Suất & Ưu Đãi</th>
                  <th className="py-4 px-4 text-left w-[14%]">Hỗ Trợ Nợ Xấu</th>
                  <th className="py-4 px-5 text-center w-[12%]">Cổng Đăng Ký</th>
                </tr>
              </thead>

              {/* Table Body */}
              <tbody className="divide-y-2 divide-slate-100">
                {filteredPartners.map((partner, index) => {
                  return (
                    <tr
                      key={partner.id}
                      className="hover:bg-blue-50/40 transition-colors group"
                    >
                      {/* Col 1: Partner Info */}
                      <td className="py-5 px-5">
                        <div className="flex items-center gap-3.5">
                          <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-100 border-2 border-slate-200 flex items-center justify-center text-3xl sm:text-4xl shadow-xs group-hover:scale-105 transition-transform shrink-0">
                            {partner.logo}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xl sm:text-2xl font-black text-slate-900 group-hover:text-blue-600 transition-colors">
                                {partner.name}
                              </span>
                              <span className={`text-[11px] font-extrabold px-2.5 py-0.5 rounded-full ${partner.themeColor.lightBg} ${partner.themeColor.text} border ${partner.themeColor.border}`}>
                                {partner.badge}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 font-medium mt-1 leading-snug">
                              {partner.tagline}
                            </p>
                            <div className="flex items-center gap-2 mt-1.5">
                              <div className="flex items-center gap-1 bg-amber-50 text-amber-800 px-2 py-0.5 rounded-md text-xs font-bold border border-amber-200">
                                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                                <span>{partner.rating}</span>
                              </div>
                              <span className="text-[11px] text-slate-400">
                                ({partner.reviewCount.toLocaleString('vi-VN')} lượt đánh giá)
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Col 2: Loan Amount (Big Typography) */}
                      <td className="py-5 px-4">
                        <div className="text-base sm:text-xl font-black text-blue-900">
                          {formatVND(partner.minAmount)}
                        </div>
                        <div className="text-xs text-slate-400 font-semibold uppercase">Đến tối đa</div>
                        <div className="text-lg sm:text-2xl font-black text-emerald-700 mt-0.5">
                          {formatVND(partner.maxAmount)}
                        </div>
                        <span className="inline-block mt-1 text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          Kỳ hạn {partner.minTermDays} - {partner.maxTermDays} ngày
                        </span>
                      </td>

                      {/* Col 3: Speed & Rate */}
                      <td className="py-5 px-4">
                        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs sm:text-sm font-extrabold">
                          <Clock className="w-4 h-4 text-emerald-600" />
                          <span>{partner.approvalSpeed}</span>
                        </div>
                        <div className="text-xs text-slate-500 font-medium mt-2">
                          Tỷ lệ duyệt thành công: <strong className="text-slate-900 font-black">{partner.approvalRatePercent}%</strong>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full mt-1 overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full rounded-full"
                            style={{ width: `${partner.approvalRatePercent}%` }}
                          />
                        </div>
                      </td>

                      {/* Col 4: Interest Rate & Promo */}
                      <td className="py-5 px-4">
                        <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900">
                          <span className="text-xs sm:text-sm font-black block">
                            {partner.firstLoanPromo}
                          </span>
                          <span className="text-[11px] text-amber-800 font-medium mt-0.5 block">
                            {partner.interestRateText}
                          </span>
                        </div>
                      </td>

                      {/* Col 5: Bad Debt Support */}
                      <td className="py-5 px-4">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-black">
                          <Shield className="w-4 h-4 text-rose-600 shrink-0" />
                          <span>{partner.badDebtSupport}</span>
                        </span>
                        <div className="text-[11px] text-slate-600 space-y-1 mt-2">
                          <div className="flex items-center gap-1">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>Chỉ cần CCCD</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>Không gọi người thân</span>
                          </div>
                        </div>
                      </td>

                      {/* Col 6: Big CTA Button to Exact Link */}
                      <td className="py-5 px-5 text-center">
                        <a
                          href={partner.officialUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`w-full py-4 px-4 rounded-2xl ${partner.themeColor.btn} font-black text-xs sm:text-sm shadow-lg hover:shadow-xl transition-all flex flex-col items-center justify-center gap-1 cursor-pointer active:scale-95 group/btn`}
                        >
                          <span className="tracking-wide">ĐĂNG KÝ VAY</span>
                          <span className="text-[10px] opacity-90 font-bold flex items-center gap-1">
                            {partner.name} <ExternalLink className="w-3 h-3" />
                          </span>
                        </a>

                        {onSelectPartnerForApply && (
                          <button
                            type="button"
                            onClick={() => onSelectPartnerForApply(partner)}
                            className="mt-2 text-[11px] text-blue-600 hover:text-blue-800 font-bold cursor-pointer underline underline-offset-2"
                          >
                            Hỗ trợ điền nhanh
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Table Footer info banner */}
          <div className="bg-slate-50 p-4 sm:p-5 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span>
                <strong>Cam kết:</strong> 100% đối tác trên bảng đã được xác thực, không thu phí trước, tiền giải ngân chuyển thẳng số tài khoản ngân hàng chính chủ.
              </span>
            </div>
            <span className="text-slate-400 font-medium">Cập nhật lúc: 24/7 theo thời gian thực</span>
          </div>
        </div>
      ) : (
        /* VIEW MODE 2: LARGE CARDS (DẠNG THẺ TO RỘNG) */
        <div className="space-y-5">
          {filteredPartners.map((partner) => {
            return (
              <div
                key={partner.id}
                className="bg-white rounded-3xl border-2 border-slate-200/90 shadow-md hover:shadow-xl transition-all overflow-hidden p-6 sm:p-8"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                  {/* Left: Brand & Badges */}
                  <div className="lg:col-span-4 flex items-start gap-4">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-100 border-2 border-slate-200 flex items-center justify-center text-4xl sm:text-5xl shrink-0 shadow-xs">
                      {partner.logo}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
                          {partner.name}
                        </h3>
                        <span className={`text-xs font-black px-2.5 py-0.5 rounded-full ${partner.themeColor.lightBg} ${partner.themeColor.text} border ${partner.themeColor.border}`}>
                          {partner.badge}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
                        {partner.tagline}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 font-black border border-rose-100">
                          {partner.badDebtSupport}
                        </span>
                        <span className="text-xs px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-black border border-emerald-100">
                          {partner.approvalSpeed}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Middle: Key Loan Terms */}
                  <div className="lg:col-span-5 grid grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200/70">
                    <div>
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Hạn mức phê duyệt</span>
                      <span className="text-lg sm:text-2xl font-black text-blue-900 block mt-0.5">
                        {formatVND(partner.minAmount)} - {formatVND(partner.maxAmount)}
                      </span>
                      <span className="text-xs text-slate-500 mt-1 block">Tỷ lệ duyệt: <strong className="text-emerald-700">{partner.approvalRatePercent}%</strong></span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Ưu đãi lãi suất</span>
                      <span className="text-sm sm:text-base font-black text-emerald-700 block mt-0.5">
                        {partner.firstLoanPromo}
                      </span>
                      <span className="text-[11px] text-slate-500 mt-1 block leading-tight">{partner.interestRateText}</span>
                    </div>
                  </div>

                  {/* Right: Big CTA Button to Exact Link */}
                  <div className="lg:col-span-3 flex flex-col gap-2">
                    <a
                      href={partner.officialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`w-full py-4 px-6 rounded-2xl ${partner.themeColor.btn} font-black text-base shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95`}
                    >
                      <span>VAY TẠI {partner.name.toUpperCase()}</span>
                      <ExternalLink className="w-5 h-5" />
                    </a>

                    <div className="flex items-center justify-between text-xs text-slate-500 px-2">
                      <span>Duyệt 100% trong 5 phút</span>
                      {onSelectPartnerForApply && (
                        <button
                          type="button"
                          onClick={() => onSelectPartnerForApply(partner)}
                          className="text-blue-600 hover:text-blue-800 font-bold underline"
                        >
                          Điền hỗ trợ
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Helpful Advice Banner */}
      <div className="p-5 rounded-3xl bg-linear-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-2xl shrink-0 shadow-md">
            💡
          </div>
          <div>
            <h4 className="text-base sm:text-lg font-black text-white">
              Kinh Nghiệm Nhận Tiền Ngay Trong 5 Phút:
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              Để đảm bảo giải ngân thành công, bạn nên nộp hồ sơ đồng thời vào <strong>MoneyCat</strong> và <strong>Vay VND</strong> (hoặc <strong>Jeff</strong> nếu nợ xấu nặng). Tiền sẽ được chuyển ngay vào số tài khoản ngân hàng chính chủ của bạn.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <a
            href="https://go.3rdvn.io.vn/t/b1bb1922c3a8915d"
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
          >
            <span>Vay MoneyCat 0% Lãi</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
};
