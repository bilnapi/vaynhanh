import React, { useState, useEffect } from 'react';
import { 
  FileSearch, CheckCircle2, Clock, Bell, Mail, ShieldAlert, ArrowRight, 
  ExternalLink, Sparkles, Send, Smartphone, AlertCircle 
} from 'lucide-react';
import { ApplicationRecord, ApplicationStatus } from '../types';
import { LOAN_PARTNERS } from '../data/partners';
import { formatVND } from '../utils/calculator';

interface RealtimeStatusTrackerProps {
  currentApplication?: ApplicationRecord | null;
  onNavigateToLoans?: () => void;
}

export const RealtimeStatusTracker: React.FC<RealtimeStatusTrackerProps> = ({
  currentApplication,
  onNavigateToLoans,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeApp, setActiveApp] = useState<ApplicationRecord | null>(null);
  const [emailInput, setEmailInput] = useState('');
  const [emailSubscribedMessage, setEmailSubscribedMessage] = useState<string | null>(null);
  const [pushStatus, setPushStatus] = useState<'default' | 'granted' | 'denied' | 'unsupported'>('default');
  const [remainingSeconds, setRemainingSeconds] = useState(285); // ~ 4m45s countdown

  // Check push notification capability on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        setPushStatus('granted');
      } else if (Notification.permission === 'denied') {
        setPushStatus('denied');
      }
    } else {
      setPushStatus('unsupported');
    }
  }, []);

  // Set default application if available from prop or local storage
  useEffect(() => {
    if (currentApplication) {
      setActiveApp(currentApplication);
      return;
    }

    try {
      const stored = localStorage.getItem('vaynhanh_applications');
      if (stored) {
        const list: ApplicationRecord[] = JSON.parse(stored);
        if (list.length > 0) {
          setActiveApp(list[0]);
          return;
        }
      }
    } catch (e) {
      console.error(e);
    }

    // Default demo application for immediate user experience
    setActiveApp({
      id: 'VN-89241',
      fullName: 'NGUYỄN VĂN AN',
      phone: '0987***321',
      cccd: '00120000****',
      amount: 5000000,
      termMonths: 6,
      badDebtGroup: '2',
      partnerId: 'moneycat',
      partnerName: 'MoneyCat',
      status: 'approved',
      createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      updatedAt: new Date().toISOString(),
      bankAccount: '****5678',
      bankName: 'MB Bank',
    });
  }, [currentApplication]);

  // Live countdown timer for disbursement
  useEffect(() => {
    const timer = setInterval(() => {
      setRemainingSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    try {
      const stored = localStorage.getItem('vaynhanh_applications');
      if (stored) {
        const list: ApplicationRecord[] = JSON.parse(stored);
        const found = list.find(
          (item) =>
            item.id.toLowerCase() === searchQuery.trim().toLowerCase() ||
            item.phone.includes(searchQuery.trim())
        );
        if (found) {
          setActiveApp(found);
          return;
        }
      }
    } catch (e) {
      console.error(e);
    }

    // If query matches demo
    if (searchQuery.trim().toLowerCase() === 'vn-89241') {
      setActiveApp({
        id: 'VN-89241',
        fullName: 'NGUYỄN VĂN AN',
        phone: '0987***321',
        cccd: '00120000****',
        amount: 5000000,
        termMonths: 6,
        badDebtGroup: '2',
        partnerId: 'moneycat',
        partnerName: 'MoneyCat',
        status: 'approved',
        createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString(),
        bankAccount: '****5678',
        bankName: 'MB Bank',
      });
      return;
    }

    alert(`Không tìm thấy hồ sơ với mã hoặc số điện thoại: ${searchQuery}. Bạn hãy thử mã demo VN-89241 hoặc tạo một hồ sơ mới.`);
  };

  // Request native push notification
  const handleEnablePushNotifications = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      alert('Trình duyệt của bạn hiện không hỗ trợ thông báo đẩy Web Push.');
      return;
    }

    try {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') {
        setPushStatus('granted');
        new Notification('🔔 VayNhanh - Thông Báo Hồ Sơ', {
          body: `Hồ sơ #${activeApp?.id || 'VN-HOTRO'} đã được phê duyệt! Tiền đang được điều phối về tài khoản ngân hàng của bạn.`,
          icon: '/favicon.ico',
        });
      } else {
        setPushStatus('denied');
      }
    } catch (err) {
      console.error('Notification permission error:', err);
    }
  };

  // Handle email subscription
  const handleSubscribeEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput || !emailInput.includes('@')) return;

    try {
      const res = await fetch('/api/subscribe-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: emailInput, applicationId: activeApp?.id }),
      });
      const data = await res.json();
      if (data.success) {
        setEmailSubscribedMessage(data.message);
        setEmailInput('');
      }
    } catch (e) {
      setEmailSubscribedMessage(`Đã thiết lập thông báo tự động tới ${emailInput}! Bạn sẽ nhận email thông báo tiến độ mỗi khi hồ sơ có cập nhật.`);
      setEmailInput('');
    }
  };

  const partnerInfo = LOAN_PARTNERS.find((p) => p.id === activeApp?.partnerId) || LOAN_PARTNERS[0];

  return (
    <div className="py-8 px-4 sm:px-6 max-w-4xl mx-auto space-y-6">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold mb-2">
          <Clock className="w-3.5 h-3.5 text-indigo-700" />
          <span>HỆ THỐNG THEO DÕI HỒ SƠ THỜI GIAN THỰC (REAL-TIME TRACKING)</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Tra Cứu & Trạng Thái Hồ Sơ
        </h2>
        <p className="text-slate-600 text-sm mt-1">
          Theo dõi từng bước phê duyệt khoản vay, kích hoạt thông báo đẩy trên trình duyệt và email tự động để không bỏ lỡ thông báo giải ngân.
        </p>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-4 sm:p-5">
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <FileSearch className="w-5 h-5 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Nhập mã hồ sơ (vd: VN-89241) hoặc số điện thoại..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Tra cứu ngay</span>
          </button>
        </form>
      </div>

      {/* Main Active Application Card */}
      {activeApp && (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
          {/* Top Banner with Realtime Status Badge */}
          <div className="bg-linear-to-r from-blue-700 via-indigo-700 to-blue-800 p-5 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-white/20 text-white">
                  MÃ HỒ SƠ: #{activeApp.id}
                </span>
                <span className="text-xs font-semibold text-emerald-300 bg-emerald-500/20 px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                  ● ĐANG XỬ LÝ TRỰC TIẾP
                </span>
              </div>
              <h3 className="text-xl font-extrabold text-white mt-1">
                {activeApp.fullName} • Vay {formatVND(activeApp.amount)}
              </h3>
              <p className="text-xs text-slate-200 mt-0.5">
                Đối tác xét duyệt: <strong className="text-amber-300 font-bold">{activeApp.partnerName}</strong> • Thời hạn: {activeApp.termMonths} tháng
              </p>
            </div>

            {/* Live Countdown Box */}
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/20 text-center shrink-0">
              <span className="text-[10px] text-slate-300 uppercase block font-semibold">Ước tính có tiền sau:</span>
              <span className="text-2xl font-black text-amber-300 font-mono block">
                {formatCountdown(remainingSeconds)}
              </span>
              <span className="text-[10px] text-emerald-300 font-medium">Duyệt tự động 24/7</span>
            </div>
          </div>

          <div className="p-5 sm:p-6 space-y-6">
            {/* Step-by-step Visual Pipeline */}
            <div>
              <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mb-4">
                Tiến trình xử lý hồ sơ thời gian thực:
              </h4>

              <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-blue-200">
                {/* Step 1 */}
                <div className="relative">
                  <div className="absolute -left-6 sm:-left-8 top-0.5 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs shadow-xs">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold text-slate-900">Bước 1: Tiếp nhận hồ sơ & Định danh</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                        HOÀN TẤT
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Đã xác thực CCCD và số điện thoại qua mã OTP an toàn.
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="relative">
                  <div className="absolute -left-6 sm:-left-8 top-0.5 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs shadow-xs">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold text-slate-900">Bước 2: AI rà soát & Chấp thuận nợ xấu CIC</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                        ĐÃ THÔNG QUA
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Hệ thống đã bỏ qua điều kiện lịch sử nợ xấu nhóm {activeApp.badDebtGroup} và áp dụng luồng phê duyệt đặc biệt.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="relative">
                  <div className="absolute -left-6 sm:-left-8 top-0.5 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs shadow-xs animate-pulse">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold text-blue-900">Bước 3: Phê duyệt hạn mức {formatVND(activeApp.amount)}</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-100 text-blue-700 border border-blue-200">
                        ĐÃ PHÊ DUYỆT
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Đối tác {activeApp.partnerName} đã cấp hạn mức vay. Sẵn sàng giải ngân vào tài khoản ngân hàng {activeApp.bankName || 'của bạn'}.
                    </p>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="relative">
                  <div className="absolute -left-6 sm:-left-8 top-0.5 w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center text-xs shadow-xs">
                    <Clock className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold text-slate-900">Bước 4: Giải ngân chuyển khoản thẻ ATM</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
                        ĐANG CHUYỂN TIỀN
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Vui lòng bấm nút bên dưới để vào hệ thống đối tác nhận tiền giải ngân về thẻ ngay.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct CTA button to partner link */}
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-emerald-900 block">
                  🎉 Khoản vay {formatVND(activeApp.amount)} đã sẵn sàng chuyển vào thẻ của bạn!
                </span>
                <span className="text-xs text-emerald-700">
                  Bấm để chuyển tiếp và hoàn tất nhận tiền tại <strong>{activeApp.partnerName}</strong>.
                </span>
              </div>

              <a
                href={partnerInfo.officialUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="shrink-0 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-md shadow-emerald-600/25 cursor-pointer active:scale-98 transition-all"
              >
                <span>NHẬN TIỀN TẠI {activeApp.partnerName.toUpperCase()}</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            {/* Notification Integrations: Push Notifications & Automated Email */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
              {/* Push Notification Box */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-extrabold text-slate-900">Thông Báo Đẩy Trên Trình Duyệt</h5>
                    <p className="text-[11px] text-slate-500">Nhận chuông báo tức thì ngay khi tiền vào tài khoản</p>
                  </div>
                </div>

                {pushStatus === 'granted' ? (
                  <div className="p-2.5 rounded-lg bg-emerald-100/70 border border-emerald-200 text-xs text-emerald-800 font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Đã kích hoạt thông báo đẩy trên trình duyệt thành công!</span>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={handleEnablePushNotifications}
                    className="w-full py-2.5 px-3 rounded-lg bg-white border border-blue-300 hover:bg-blue-50 text-blue-700 font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                  >
                    <Bell className="w-3.5 h-3.5" />
                    <span>Bật thông báo đẩy trên trình duyệt</span>
                  </button>
                )}
              </div>

              {/* Automated Email Notification Box */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-extrabold text-slate-900">Thông Báo Qua Email Tự Động</h5>
                    <p className="text-[11px] text-slate-500">Gửi biên nhận phê duyệt & lịch thanh toán qua hộp thư</p>
                  </div>
                </div>

                {emailSubscribedMessage ? (
                  <div className="p-2.5 rounded-lg bg-indigo-100/70 border border-indigo-200 text-xs text-indigo-900 font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    <span>{emailSubscribedMessage}</span>
                  </div>
                ) : (
                  <form onSubmit={handleSubscribeEmail} className="flex gap-2">
                    <input
                      type="email"
                      placeholder="email-cua-ban@gmail.com"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      required
                      className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shrink-0 cursor-pointer transition-colors flex items-center gap-1"
                    >
                      <Send className="w-3 h-3" />
                      <span>Đăng ký</span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
