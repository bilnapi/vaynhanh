import React from 'react';
import { ShieldCheck, Zap, MessageSquareText, Calculator, FileSearch, Sparkles, PhoneCall } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openChatbot: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, openChatbot }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top micro banner */}
      <div className="bg-linear-to-r from-blue-700 via-indigo-700 to-blue-800 text-white text-xs py-1.5 px-4 font-medium">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
            </span>
            <span className="font-semibold text-emerald-300">HỆ THỐNG TRỰC 24/7:</span>
            <span className="truncate">Hỗ trợ duyệt nợ xấu CIC nhóm 1-5 trong 5 phút</span>
          </div>
          <div className="hidden sm:flex items-center gap-4 text-slate-200 text-[11px]">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Bảo mật SSL 256-Bit
            </span>
            <span>•</span>
            <span>Không gọi người thân</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Brand */}
        <button
          onClick={() => setActiveTab('loans')}
          className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-hidden"
        >
          <div className="w-10 h-10 rounded-xl bg-linear-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
            <Zap className="w-6 h-6 fill-amber-300 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-extrabold tracking-tight text-slate-900">
                Vay<span className="text-blue-600">Nhanh</span>
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-sm bg-rose-100 text-rose-700 border border-rose-200">
                Hỗ Trợ Nợ Xấu
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">Duyệt cấp tốc 5 phút • Chỉ cần CCCD</p>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => setActiveTab('loans')}
            className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
              activeTab === 'loans'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Đối Tác Cho Vay
          </button>
          <button
            onClick={() => setActiveTab('calculator')}
            className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'calculator'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Calculator className="w-4 h-4 text-blue-600" />
            Tính Lãi Suất & Biểu Đồ
          </button>

          <button
            onClick={() => setActiveTab('tracking')}
            className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'tracking'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileSearch className="w-4 h-4 text-indigo-600" />
            Tra Cứu Hồ Sơ
          </button>
        </nav>

        {/* Action Button: Chatbot */}
        <div className="flex items-center gap-2">
          <button
            onClick={openChatbot}
            className="flex items-center gap-1.5 px-3 py-2 sm:px-3.5 sm:py-2 rounded-xl bg-linear-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white text-xs sm:text-sm font-semibold shadow-sm shadow-blue-500/25 transition-all hover:shadow-md cursor-pointer active:scale-95"
          >
            <MessageSquareText className="w-4 h-4" />
            <span className="hidden sm:inline">Tư Vấn Nợ Xấu 24/7</span>
            <span className="sm:hidden">Tư Vấn 24/7</span>
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
