import React, { useState, useMemo } from 'react';
import { Calculator, Sparkles, Check, Percent, ShieldCheck, Zap, ExternalLink } from 'lucide-react';
import { calculateLoan, formatVND } from '../utils/calculator';
import { RepaymentChart } from './RepaymentChart';
import { LOAN_PARTNERS } from '../data/partners';

interface LoanCalculatorProps {
  onApplyWithDetails?: (amount: number, months: number) => void;
}

export const LoanCalculator: React.FC<LoanCalculatorProps> = ({ onApplyWithDetails }) => {
  const [amount, setAmount] = useState<number>(5000000); // 5 triệu
  const [months, setMonths] = useState<number>(6); // 6 tháng
  const [isFirstLoanPromo, setIsFirstLoanPromo] = useState<boolean>(true);
  const [customInterestRate, setCustomInterestRate] = useState<number>(14.5); // %/năm

  // Quick amount selections
  const quickAmounts = [
    { label: '2 Triệu', value: 2000000 },
    { label: '5 Triệu', value: 5000000 },
    { label: '10 Triệu', value: 10000000 },
    { label: '15 Triệu', value: 15000000 },
    { label: '20 Triệu', value: 20000000 },
    { label: '30 Triệu', value: 30000000 },
  ];

  const quickTerms = [
    { label: '1 Tháng', value: 1 },
    { label: '3 Tháng', value: 3 },
    { label: '6 Tháng', value: 6 },
    { label: '9 Tháng', value: 9 },
    { label: '12 Tháng', value: 12 },
  ];

  // Perform calculation
  const calculationResult = useMemo(() => {
    return calculateLoan({
      principal: amount,
      months,
      annualInterestRatePercent: customInterestRate,
      isFirstLoanPromo,
    });
  }, [amount, months, customInterestRate, isFirstLoanPromo]);

  // Recommended partner matching the amount
  const bestPartner = useMemo(() => {
    if (amount > 15000000) {
      return LOAN_PARTNERS.find((p) => p.id === 'jeff') || LOAN_PARTNERS[2];
    }
    if (isFirstLoanPromo) {
      return LOAN_PARTNERS.find((p) => p.id === 'moneycat') || LOAN_PARTNERS[0];
    }
    return LOAN_PARTNERS.find((p) => p.id === 'vayvnd') || LOAN_PARTNERS[1];
  }, [amount, isFirstLoanPromo]);

  return (
    <div className="py-8 px-4 sm:px-6 max-w-6xl mx-auto space-y-8">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold mb-2">
          <Calculator className="w-3.5 h-3.5 text-emerald-700" />
          <span>CÔNG CỤ TÍNH LÃI SUẤT TỰ ĐỘNG CHUẨN XÁC 100%</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Máy Tính Lãi Suất & Tiến Độ Trả Nợ
        </h2>
        <p className="text-slate-600 text-sm mt-1">
          Dễ dàng ước tính số tiền cần thanh toán hàng tháng, tổng lãi suất và xem biểu đồ tiến độ trả nợ chi tiết trước khi gửi đơn vay.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Interactive Inputs */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-6 space-y-6">
          <h3 className="font-extrabold text-slate-900 text-lg flex items-center justify-between border-b border-slate-100 pb-3">
            <span>Thiết Lập Khoản Vay</span>
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
              Chỉ cần CCCD
            </span>
          </h3>

          {/* Amount Slider */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Số tiền cần vay:
              </label>
              <span className="text-xl sm:text-2xl font-black text-blue-700">
                {formatVND(amount)}
              </span>
            </div>

            <input
              type="range"
              min={1000000}
              max={30000000}
              step={500000}
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />

            <div className="flex justify-between text-[11px] text-slate-400 font-semibold">
              <span>1.000.000đ</span>
              <span>15.000.000đ</span>
              <span>30.000.000đ</span>
            </div>

            {/* Quick chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {quickAmounts.map((q) => (
                <button
                  key={q.value}
                  type="button"
                  onClick={() => setAmount(q.value)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                    amount === q.value
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>

          {/* Months Slider */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Thời hạn vay:
              </label>
              <span className="text-xl font-black text-slate-900">
                {months} Tháng
              </span>
            </div>

            <input
              type="range"
              min={1}
              max={12}
              step={1}
              value={months}
              onChange={(e) => setMonths(Number(e.target.value))}
              className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />

            <div className="flex justify-between text-[11px] text-slate-400 font-semibold">
              <span>1 Tháng</span>
              <span>6 Tháng</span>
              <span>12 Tháng</span>
            </div>

            {/* Quick term chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {quickTerms.map((t) => (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setMonths(t.value)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                    months === t.value
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Rate Type Selection */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Chế độ tính lãi suất:
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setIsFirstLoanPromo(true)}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  isFirstLoanPromo
                    ? 'border-emerald-500 bg-emerald-50/80 shadow-xs ring-1 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-emerald-800">0% Lãi Suất Lần Đầu</span>
                  {isFirstLoanPromo && <Check className="w-4 h-4 text-emerald-600" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Áp dụng cho khách hàng mới vay lần đầu tại MoneyCat / Vay VND
                </p>
              </button>

              <button
                type="button"
                onClick={() => setIsFirstLoanPromo(false)}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  !isFirstLoanPromo
                    ? 'border-blue-500 bg-blue-50/80 shadow-xs ring-1 ring-blue-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-blue-800">Lãi Tiêu Chuẩn ({customInterestRate}%/năm)</span>
                  {!isFirstLoanPromo && <Check className="w-4 h-4 text-blue-600" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Dư nợ giảm dần từ kỳ thứ 2 theo quy định tài chính
                </p>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Calculation Summary & Immediate Recommendation */}
        <div className="lg:col-span-6 space-y-5">
          <div className="bg-linear-to-br from-slate-900 via-indigo-950 to-blue-950 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
              <span className="text-xs uppercase font-extrabold tracking-wider text-amber-300">
                KẾT QUẢ TÍNH TỰ ĐỘNG
              </span>
              <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 font-bold">
                {isFirstLoanPromo ? 'Khuyến Mãi 0% Lãi' : 'Lãi Chuẩn 14.5%'}
              </span>
            </div>

            <div className="space-y-4">
              <div>
                <span className="text-xs text-slate-300 block font-medium">Số tiền ước tính trả hàng tháng:</span>
                <span className="text-3xl sm:text-4xl font-black text-amber-300 tracking-tight">
                  {formatVND(calculationResult.monthlyPayment)}
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  (Bao gồm cả tiền gốc và tiền lãi mỗi kỳ)
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-4 border-t border-white/10 text-center">
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Tiền gốc vay</span>
                  <span className="text-xs sm:text-sm font-bold text-white block mt-0.5">
                    {formatVND(calculationResult.principal)}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Tổng tiền lãi</span>
                  <span className="text-xs sm:text-sm font-bold text-emerald-300 block mt-0.5">
                    {formatVND(calculationResult.totalInterest)}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Tổng hoàn trả</span>
                  <span className="text-xs sm:text-sm font-bold text-white block mt-0.5">
                    {formatVND(calculationResult.totalPayment)}
                  </span>
                </div>
              </div>

              {/* Best Matched Partner Direct Box */}
              <div className="mt-4 pt-4 border-t border-white/10">
                <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
                  <span className="font-semibold text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    Đơn vị phù hợp nhất với gói vay này:
                  </span>
                  <span className="text-emerald-400 font-bold">{bestPartner.approvalSpeed}</span>
                </div>

                <div className="bg-white/10 rounded-xl p-3 flex items-center justify-between gap-3 border border-white/15">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{bestPartner.logo}</span>
                    <div>
                      <div className="font-extrabold text-sm text-white">{bestPartner.name}</div>
                      <div className="text-[11px] text-slate-300">Tỷ lệ duyệt hồ sơ: {bestPartner.approvalRatePercent}%</div>
                    </div>
                  </div>

                  <a
                    href={bestPartner.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs shadow-md transition-all flex items-center gap-1 cursor-pointer shrink-0"
                  >
                    <span>VAY NGAY</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Amortization & Repayment Chart */}
      <RepaymentChart calculation={calculationResult} />
    </div>
  );
};
