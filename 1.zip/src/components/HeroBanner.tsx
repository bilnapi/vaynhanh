import React, { useState, useEffect } from 'react';
import { Shield, Clock, CheckCircle2, ChevronRight, AlertCircle, TrendingUp } from 'lucide-react';
import { LIVE_APPROVAL_NOTIFICATIONS } from '../data/partners';

interface HeroBannerProps {
  onSelectTab: (tab: string) => void;
  onOpenCICModal: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onSelectTab, onOpenCICModal }) => {
  const [currentNotifIndex, setCurrentNotifIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentNotifIndex((prev) => (prev + 1) % LIVE_APPROVAL_NOTIFICATIONS.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const activeNotif = LIVE_APPROVAL_NOTIFICATIONS[currentNotifIndex];

  return (
    <div className="relative overflow-hidden bg-linear-to-b from-blue-900 via-indigo-950 to-slate-900 text-white pt-6 pb-10 px-4 sm:px-6">
      {/* Background visual accents */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Live approval ticker bar */}
        <div className="inline-flex items-center gap-2.5 sm:gap-3 px-4 sm:px-5 py-2.5 sm:py-3 rounded-full bg-white/15 backdrop-blur-md border-2 border-white/25 text-sm sm:text-base text-slate-100 mb-5 shadow-lg shadow-black/20 animate-fade-in">
          <span className="flex h-3 w-3 relative shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-80"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-400 shadow-sm shadow-emerald-400"></span>
          </span>
          <span className="text-emerald-300 font-black tracking-wide text-xs sm:text-sm uppercase bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/30">
            Vừa giải ngân:
          </span>
          <span className="font-extrabold text-white">{activeNotif.name} ({activeNotif.city})</span>
          <span className="text-amber-300 font-black text-base sm:text-lg tracking-tight bg-amber-400/20 px-2 py-0.5 rounded-md border border-amber-300/30">
            +{activeNotif.amount}
          </span>
          <span className="text-slate-200 font-medium text-xs sm:text-sm hidden sm:inline">
            qua <strong className="text-white font-bold">{activeNotif.partner}</strong> • {activeNotif.timeAgo}
          </span>
        </div>

        {/* Hero Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-1 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold tracking-wide">
                ĐẶC TRỊ NỢ XẤU
              </span>
              <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold tracking-wide flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> DUYỆT 5 PHÚT
              </span>
              <span className="px-2.5 py-1 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold tracking-wide">
                0% LÃI SUẤT LẦN ĐẦU
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Vay Tiền Nhanh Hỗ Trợ Nợ Xấu{' '}
              <span className="bg-linear-to-r from-amber-300 via-yellow-200 to-emerald-400 bg-clip-text text-transparent">
                Duyệt 100% Trong 5 Phút
              </span>
            </h1>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Giải pháp tài chính cấp tốc cho người có nợ xấu ngân hàng (CIC nhóm 1 đến nhóm 5). Kết nối trực tiếp 4 đối tác tài chính uy tín: 
              <strong className="text-white"> MoneyCat, Vay VND, Jeff, Money Veo</strong>.
            </p>

            {/* Feature Bullets */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-amber-400 font-bold text-xs flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Chỉ CCCD
                </div>
                <p className="text-[11px] text-slate-300 mt-0.5">Không giữ giấy tờ gốc</p>
              </div>

              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-amber-400 font-bold text-xs flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Không gọi điện
                </div>
                <p className="text-[11px] text-slate-300 mt-0.5">Tuyệt đối giấu người thân</p>
              </div>

              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-amber-400 font-bold text-xs flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 5 Phút có tiền
                </div>
                <p className="text-[11px] text-slate-300 mt-0.5">Tự động chuyển thẻ ATM</p>
              </div>

              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-amber-400 font-bold text-xs flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Tỷ lệ duyệt 98%
                </div>
                <p className="text-[11px] text-slate-300 mt-0.5">Kể cả nợ xấu nhóm 1-5</p>
              </div>
            </div>

            {/* Quick Action CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                onClick={() => onSelectTab('loans')}
                className="px-6 py-3 rounded-xl bg-linear-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-sm sm:text-base shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98"
              >
                <span>Xem 4 Đối Tác Cho Vay Ngay</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectTab('calculator')}
                className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Tính Lãi Suất Tự Động</span>
              </button>

              <button
                onClick={onOpenCICModal}
                className="text-xs text-slate-300 hover:text-white underline underline-offset-4 flex items-center justify-center gap-1 py-1"
              >
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>Tra cứu các nhóm nợ xấu CIC</span>
              </button>
            </div>
          </div>

          {/* Quick Snapshot Card on Desktop */}
          <div className="lg:col-span-4 bg-linear-to-br from-white/10 to-white/5 border border-white/15 rounded-2xl p-5 backdrop-blur-md shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-400" />
                <span className="font-bold text-sm text-white">Cam Kết Dịch Vụ</span>
              </div>
              <span className="text-[11px] font-semibold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                100% Miễn Phí
              </span>
            </div>

            <div className="space-y-3 text-xs text-slate-200">
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0 mt-0.5 font-bold">
                  ✓
                </div>
                <div>
                  <strong className="text-white block font-semibold">Không thu bất kỳ khoản phí trước</strong>
                  <span className="text-slate-400">Cảnh giác với bên yêu cầu đặt cọc giải ngân</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-300 flex items-center justify-center shrink-0 mt-0.5 font-bold">
                  ✓
                </div>
                <div>
                  <strong className="text-white block font-semibold">Chấp nhận nợ xấu ngân hàng & app</strong>
                  <span className="text-slate-400">Xét duyệt điểm tín nhiệm độc lập qua số điện thoại</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0 mt-0.5 font-bold">
                  ✓
                </div>
                <div>
                  <strong className="text-white block font-semibold">Duyệt và nhận tiền 24/7</strong>
                  <span className="text-slate-400">Kể cả thứ 7, Chủ Nhật và ngày lễ Tết</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
