import React, { useState } from 'react';
import { ShieldCheck, Lock, CheckCircle2, AlertCircle, ArrowRight, Sparkles, Building, Phone, User, CreditCard, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';
import { LOAN_PARTNERS, CIC_DEBT_GROUPS } from '../data/partners';
import { ApplicationRecord, LoanPartner } from '../types';
import { formatVND } from '../utils/calculator';

interface ApplicationFormProps {
  initialAmount?: number;
  initialMonths?: number;
  initialPartnerId?: string;
  onApplicationCreated: (app: ApplicationRecord) => void;
}

export const ApplicationForm: React.FC<ApplicationFormProps> = ({
  initialAmount = 5000000,
  initialMonths = 6,
  initialPartnerId = 'moneycat',
  onApplicationCreated,
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [cccd, setCccd] = useState('');
  const [city, setCity] = useState('Hà Nội');
  const [amount, setAmount] = useState<number>(initialAmount);
  const [termMonths, setTermMonths] = useState<number>(initialMonths);
  const [badDebtGroup, setBadDebtGroup] = useState('2');
  const [partnerId, setPartnerId] = useState(initialPartnerId);
  const [email, setEmail] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [bankName, setBankName] = useState('Vietcombank');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [submittedApp, setSubmittedApp] = useState<ApplicationRecord | null>(null);

  const selectedPartner = LOAN_PARTNERS.find((p) => p.id === partnerId) || LOAN_PARTNERS[0];

  const validate = () => {
    const errs: { [key: string]: string } = {};

    if (!fullName.trim() || fullName.trim().length < 3) {
      errs.fullName = 'Vui lòng nhập họ và tên đầy đủ theo CCCD.';
    }

    const cleanPhone = phone.replace(/\s+/g, '');
    const phoneRegex = /^(03|05|07|08|09)\d{8}$/;
    if (!phoneRegex.test(cleanPhone)) {
      errs.phone = 'Số điện thoại không hợp lệ (cần 10 chữ số, bắt đầu 03, 05, 07, 08, 09).';
    }

    const cleanCccd = cccd.replace(/\s+/g, '');
    if (!/^\d{12}$/.test(cleanCccd) && !/^\d{9}$/.test(cleanCccd)) {
      errs.cccd = 'Số CCCD phải gồm 12 chữ số (hoặc CMND 9 số).';
    }

    if (email && !email.includes('@')) {
      errs.email = 'Địa chỉ email không hợp lệ.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    // Simulate safe SSL processing
    setTimeout(() => {
      const generatedId = `VN-${Math.floor(10000 + Math.random() * 90000)}`;
      const newApp: ApplicationRecord = {
        id: generatedId,
        fullName: fullName.trim(),
        phone: phone.trim(),
        cccd: cccd.trim(),
        amount,
        termMonths,
        badDebtGroup,
        partnerId,
        partnerName: selectedPartner.name,
        status: 'submitted',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        email: email.trim() || undefined,
        bankAccount: bankAccount.trim() || undefined,
        bankName,
      };

      // Save to localStorage
      try {
        const stored = localStorage.getItem('vaynhanh_applications');
        const list: ApplicationRecord[] = stored ? JSON.parse(stored) : [];
        list.unshift(newApp);
        localStorage.setItem('vaynhanh_applications', JSON.stringify(list));
      } catch (e) {
        console.error('Storage error:', e);
      }

      setIsSubmitting(false);
      setSubmittedApp(newApp);

      // Trigger celebratory confetti
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });

      onApplicationCreated(newApp);
    }, 900);
  };

  if (submittedApp) {
    return (
      <div className="py-8 px-4 sm:px-6 max-w-2xl mx-auto">
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl p-6 sm:p-8 text-center space-y-6 animate-fade-in">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-2xl shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              HỒ SƠ ĐÃ ĐƯỢC TIẾP NHẬN THÀNH CÔNG
            </span>
            <h3 className="text-2xl font-black text-slate-900 mt-2">
              Mã Hồ Sơ: <span className="text-blue-600 font-mono">{submittedApp.id}</span>
            </h3>
            <p className="text-sm text-slate-600 mt-2 max-w-lg mx-auto">
              Chúc mừng <strong>{submittedApp.fullName}</strong>! Hồ sơ đề xuất vay <strong className="text-blue-700">{formatVND(submittedApp.amount)}</strong> tại <strong>{submittedApp.partnerName}</strong> đã được hệ thống AI ưu tiên duyệt hỗ trợ nợ xấu.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-left text-xs space-y-2.5">
            <div className="flex justify-between">
              <span className="text-slate-500">Đối tác giải ngân:</span>
              <strong className="text-slate-900 font-bold">{submittedApp.partnerName}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Số tiền đề xuất:</span>
              <strong className="text-emerald-700 font-bold">{formatVND(submittedApp.amount)}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Tình trạng nợ xấu:</span>
              <span className="text-slate-800 font-semibold">Nhóm {submittedApp.badDebtGroup}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Thời gian duyệt dự kiến:</span>
              <span className="text-blue-700 font-bold">5 phút (Tự động)</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 text-left">
            <strong className="font-bold block mb-1">⚡ Bước cuối cùng để nhận tiền vào thẻ ATM:</strong>
            Nhấn nút bên dưới để chuyển tiếp đến cổng giải ngân chính thức của <strong>{submittedApp.partnerName}</strong> và xác thực số điện thoại để tiền về tài khoản ngay!
          </div>

          <div className="space-y-3">
            <a
              href={selectedPartner.officialUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-4 px-6 rounded-2xl bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-base shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
            >
              <span>VÀO CỔNG {submittedApp.partnerName.toUpperCase()} NHẬN TIỀN NGAY</span>
              <ExternalLink className="w-5 h-5" />
            </a>

            <button
              type="button"
              onClick={() => setSubmittedApp(null)}
              className="text-xs text-slate-500 hover:text-slate-700 underline underline-offset-4 cursor-pointer"
            >
              Tạo thêm hồ sơ tại đối tác khác để tăng tỷ lệ duyệt
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 px-4 sm:px-6 max-w-4xl mx-auto space-y-6">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold mb-2">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
          <span>HỆ THỐNG ĐĂNG KÝ TRỰC TUYẾN BẢO MẬT SSL 256-BIT</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Đăng Ký Vay Trực Tuyến Nhanh
        </h2>
        <p className="text-slate-600 text-sm mt-1">
          Điền thông tin cơ bản trong 1 phút. Hệ thống tự động mã hóa và chuyển hồ sơ đến đối tác phê duyệt trong 5 phút.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-8">
        {/* Security badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6 p-3 rounded-xl bg-slate-50 border border-slate-200/60 text-xs text-slate-600 text-center">
          <div className="flex items-center justify-center gap-1.5 font-semibold text-emerald-700">
            <Lock className="w-3.5 h-3.5" /> Mã hóa SSL
          </div>
          <div className="flex items-center justify-center gap-1.5 font-semibold text-blue-700">
            <CheckCircle2 className="w-3.5 h-3.5" /> Không gọi người thân
          </div>
          <div className="flex items-center justify-center gap-1.5 font-semibold text-indigo-700">
            <Sparkles className="w-3.5 h-3.5" /> Duyệt cả nợ xấu
          </div>
          <div className="flex items-center justify-center gap-1.5 font-semibold text-amber-700">
            <ShieldCheck className="w-3.5 h-3.5" /> 0đ Phí hồ sơ
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Step 1: Chọn đối tác */}
          <div>
            <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wider block mb-2">
              1. Chọn đối tác tài chính muốn vay:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {LOAN_PARTNERS.map((partner) => {
                const isSelected = partner.id === partnerId;
                return (
                  <button
                    key={partner.id}
                    type="button"
                    onClick={() => setPartnerId(partner.id)}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/80 ring-2 ring-blue-500 shadow-xs'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xl">{partner.logo}</span>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                    </div>
                    <div className="font-extrabold text-sm text-slate-900 mt-1">{partner.name}</div>
                    <div className="text-[10px] text-slate-500 font-medium">{partner.approvalSpeed}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Khoản tiền & Nợ xấu */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Số tiền bạn cần vay:
              </label>
              <select
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                <option value={2000000}>2.000.000 VNĐ (Phổ biến)</option>
                <option value={3000000}>3.000.000 VNĐ</option>
                <option value={5000000}>5.000.000 VNĐ (Được khuyên dùng)</option>
                <option value={10000000}>10.000.000 VNĐ</option>
                <option value={15000000}>15.000.000 VNĐ</option>
                <option value={20000000}>20.000.000 VNĐ</option>
                <option value={30000000}>30.000.000 VNĐ (Gói Jeff)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Tình trạng tín dụng CIC hiện tại:
              </label>
              <select
                value={badDebtGroup}
                onChange={(e) => setBadDebtGroup(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                <option value="0">Không có nợ xấu (Điểm tín dụng tốt)</option>
                <option value="1">Nhóm 1: Quá hạn dưới 10 ngày</option>
                <option value="2">Nhóm 2: Nợ cần chú ý (10 - 90 ngày)</option>
                <option value="3">Nhóm 3: Nợ dưới tiêu chuẩn (91 - 180 ngày)</option>
                <option value="4">Nhóm 4: Nợ nghi ngờ (181 - 360 ngày)</option>
                <option value="5">Nhóm 5: Nợ xấu lâu năm (Trên 360 ngày)</option>
              </select>
            </div>
          </div>

          {/* Step 3: Thông tin cá nhân */}
          <div className="space-y-4 pt-2 border-t border-slate-100">
            <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
              2. Thông tin người vay (Bảo mật 100%):
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Họ và tên (in hoa theo CCCD):
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    placeholder="NGUYỄN VĂN AN"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500 uppercase"
                  />
                </div>
                {errors.fullName && <p className="text-rose-600 text-xs mt-1">{errors.fullName}</p>}
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Số điện thoại chính chủ (để nhận mã OTP):
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="tel"
                    placeholder="0912 345 678"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                {errors.phone && <p className="text-rose-600 text-xs mt-1">{errors.phone}</p>}
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Số Căn Cước Công Dân (12 số):
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    maxLength={12}
                    placeholder="001200001234"
                    value={cccd}
                    onChange={(e) => setCccd(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
                {errors.cccd && <p className="text-rose-600 text-xs mt-1">{errors.cccd}</p>}
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Email nhận thông báo trạng thái tự động (Tùy chọn):
                </label>
                <input
                  type="email"
                  placeholder="nguyenvanan@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
                {errors.email && <p className="text-rose-600 text-xs mt-1">{errors.email}</p>}
              </div>
            </div>

            {/* Bank details for disbursement */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Ngân hàng nhận tiền:
                </label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Vietcombank">Vietcombank</option>
                  <option value="MB Bank">MB Bank (Quân Đội)</option>
                  <option value="Techcombank">Techcombank</option>
                  <option value="VPBank">VPBank</option>
                  <option value="ACB">ACB (Á Châu)</option>
                  <option value="VietinBank">VietinBank</option>
                  <option value="BIDV">BIDV</option>
                  <option value="TPBank">TPBank</option>
                  <option value="Khác">Ngân hàng khác</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Số tài khoản ngân hàng chính chủ:
                </label>
                <input
                  type="text"
                  placeholder="10189283719"
                  value={bankAccount}
                  onChange={(e) => setBankAccount(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Submit CTA */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 px-6 rounded-2xl bg-linear-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 text-white font-extrabold text-base shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 active:scale-98"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Đang mã hóa hồ sơ & kết nối đối tác...</span>
                </>
              ) : (
                <>
                  <span>GỬI HỒ SƠ ĐỀ XUẤT VAY DUYỆT 5 PHÚT</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>

            <p className="text-[11px] text-center text-slate-500">
              Bằng việc bấm gửi hồ sơ, bạn đồng ý với chính sách bảo mật thông tin và cam kết các thông tin khai báo là hoàn toàn chính xác.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
