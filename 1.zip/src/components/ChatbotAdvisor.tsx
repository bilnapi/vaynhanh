import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquareText, X, Send, Bot, User, Sparkles, ExternalLink, 
  ChevronRight, RefreshCw, HelpCircle, ShieldCheck, Zap 
} from 'lucide-react';
import { ChatMessage } from '../types';
import { LOAN_PARTNERS } from '../data/partners';

interface ChatbotAdvisorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ChatbotAdvisor: React.FC<ChatbotAdvisorProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'bot',
      text: `Xin chào! Tôi là Trợ Lý Tài Chính 24/7 của VayNhanh.\n\nTôi chuyên tư vấn giải pháp vay tiền hỗ trợ nợ xấu (CIC nhóm 1-5), hướng dẫn hồ sơ duyệt 5 phút tại MoneyCat, Vay VND, Jeff và Money Veo. Bạn cần tôi hỗ trợ điều gì hôm nay?`,
      timestamp: 'Vừa xong',
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickQuestions = [
    'Nợ xấu nhóm 2, 3 có vay được không?',
    'MoneyCat, Vay VND, Jeff hay Money Veo duyệt dễ nhất?',
    'Vay có bị gọi điện cho người thân không?',
    'Điều kiện và thủ tục nhận tiền qua ATM?',
    'Cách tính lãi suất 0% lần đầu thế nào?',
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputValue).trim();
    if (!text || isTyping) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Vừa xong',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      });

      if (!response.ok) {
        throw new Error('Lỗi kết nối máy chủ');
      }

      const data = await response.json();
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: data.reply,
        timestamp: 'Vừa xong',
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      const fallbackMsg: ChatMessage = {
        id: `bot-fallback-${Date.now()}`,
        sender: 'bot',
        text: `Chào bạn! Cả 4 đối tác MoneyCat, Vay VND, Jeff và Money Veo đều đang tiếp nhận hồ sơ hỗ trợ nợ xấu trực tuyến. Nếu bạn đang cần vay gấp từ 1 - 10 triệu trong 5 phút, hãy nhấn đăng ký MoneyCat (0% lãi suất lần đầu) hoặc Jeff (hạn mức tới 30 triệu)!`,
        timestamp: 'Vừa xong',
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="w-full sm:max-w-lg h-[92vh] sm:h-[620px] bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="bg-linear-to-r from-blue-700 via-indigo-700 to-blue-800 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-amber-300">
                <Bot className="w-6 h-6" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-blue-700" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-extrabold text-sm sm:text-base leading-none">Chuyên Gia Tài Chính AI 24/7</h3>
                <span className="text-[10px] bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded-full font-bold">
                  Online
                </span>
              </div>
              <p className="text-[11px] text-slate-200 mt-1">
                Tư vấn nợ xấu, thủ tục 5 phút & so sánh đối tác
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Partner Quick Jump Bar */}
        <div className="bg-slate-100 border-b border-slate-200 px-3 py-2 flex items-center gap-2 overflow-x-auto scrollbar-none shrink-0 text-xs">
          <span className="text-[10px] uppercase font-bold text-slate-500 whitespace-nowrap">Cổng Vay Nhanh:</span>
          {LOAN_PARTNERS.map((p) => (
            <a
              key={p.id}
              href={p.officialUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:border-blue-500 hover:text-blue-600 font-bold text-[11px] text-slate-700 whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
            >
              <span>{p.logo}</span>
              <span>{p.name}</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          ))}
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
          {messages.map((msg) => {
            const isBot = msg.sender === 'bot';
            return (
              <div
                key={msg.id}
                className={`flex items-start gap-2.5 ${isBot ? '' : 'flex-row-reverse'}`}
              >
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs ${
                    isBot ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-800 text-white'
                  }`}
                >
                  {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>

                <div
                  className={`max-w-[82%] sm:max-w-[78%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-xs whitespace-pre-line ${
                    isBot
                      ? 'bg-white text-slate-800 border border-slate-200/80 rounded-tl-xs'
                      : 'bg-blue-600 text-white rounded-tr-xs font-medium'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl px-4 py-2 flex items-center gap-1 shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce" />
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce [animation-delay:0.2s]" />
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-2.5 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0">
          <HelpCircle className="w-3.5 h-3.5 text-slate-400 shrink-0 ml-1" />
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendMessage(q)}
              className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer border border-slate-200/60"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Nhập câu hỏi về nợ xấu, cách vay..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm transition-all disabled:opacity-40 cursor-pointer shrink-0 shadow-xs flex items-center gap-1.5"
            >
              <span>Gửi</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
