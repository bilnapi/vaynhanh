import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle, CheckCircle } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Nợ xấu CIC nhóm mấy thì được hỗ trợ vay tại VayNhanh?',
      a: 'Hệ thống VayNhanh kết nối trực tiếp với 4 đối tác lớn: MoneyCat và Vay VND hỗ trợ mạnh cho khách hàng nợ chú ý nhóm 1, 2 và một phần nhóm 3; trong khi Jeff (nền tảng kết nối hơn 20 tổ chức tài chính) hỗ trợ giải ngân ngay cả với nợ xấu nhóm 3, 4, 5. Money Veo áp dụng công nghệ FinTech hiện đại xét duyệt điểm tín nhiệm độc lập qua SIM và CCCD.',
    },
    {
      q: 'Thời gian xét duyệt và nhận tiền giải ngân là bao lâu?',
      a: 'Quá trình xét duyệt diễn ra tự động 100% bằng trí tuệ nhân tạo chỉ trong khoảng 3 đến 5 phút. Ngay khi được phê duyệt thành công, tiền sẽ được chuyển thẳng về số tài khoản ngân hàng (ATM) chính chủ của bạn trong vòng 10 - 15 phút.',
    },
    {
      q: 'Vay tại các đối tác này có bị gọi điện làm phiền người thân không?',
      a: 'Tuyệt đối KHÔNG. Các đối tác MoneyCat, Vay VND, Jeff, Money Veo đều áp dụng quy trình thẩm định số hóa tự động qua máy chủ bảo mật, không yêu cầu số điện thoại tham chiếu người thân, không gọi điện đến cơ quan làm việc, bảo đảm sự riêng tư tuyệt đối cho khách hàng.',
    },
    {
      q: 'Chương trình ưu đãi 0% lãi suất lần đầu áp dụng như thế nào?',
      a: 'Khách hàng đăng ký khoản vay đầu tiên tại MoneyCat hoặc Vay VND sẽ được hưởng 0% lãi suất và 0% phí dịch vụ trong kỳ hạn đầu tiên (thường từ 7 đến 14 ngày). Bạn chỉ cần hoàn trả đúng số tiền gốc đã mượn mà không phải trả thêm bất kỳ khoản lãi nào.',
    },
    {
      q: 'Tôi có thể đăng ký cùng lúc cả 4 đối tác (MoneyCat, Vay VND, Jeff, Money Veo) được không?',
      a: 'HOÀN TOÀN ĐƯỢC và ĐÂY LÀ MẸO TỐT NHẤT! Việc nộp hồ sơ ở 2 đến 3 đối tác cùng lúc không làm giảm điểm tín dụng của bạn, ngược lại giúp tăng tỷ lệ được duyệt lên tới 99% và giúp bạn có thể nhận được tổng số tiền giải ngân lớn hơn để giải quyết công việc khẩn cấp.',
    },
    {
      q: 'Cần chuẩn bị những giấy tờ gì trước khi bấm đăng ký?',
      a: 'Bạn chỉ cần chuẩn bị: (1) Căn Cước Công Dân (CCCD/CMND) bản gốc còn hạn sử dụng; (2) Số điện thoại chính chủ đang hoạt động để nhận mã OTP; (3) Tài khoản ngân hàng (ATM) đứng tên bạn để nhận tiền.',
    },
  ];

  return (
    <section className="py-8 px-4 sm:px-6 max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-200 text-slate-800 text-xs font-bold mb-2">
          <HelpCircle className="w-3.5 h-3.5 text-slate-600" />
          <span>GIẢI ĐÁP THẮC MẮC PHỔ BIẾN</span>
        </div>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Câu Hỏi Thường Gặp Về Vay Nợ Xấu
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          Những điều cần biết để tối đa cơ hội giải ngân thành công trong 5 phút
        </p>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden transition-colors"
            >
              <button
                type="button"
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-3 cursor-pointer"
              >
                <span className="font-extrabold text-sm sm:text-base text-slate-900">
                  {faq.q}
                </span>
                <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                  isOpen ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
                }`}>
                  {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </button>

              {isOpen && (
                <div className="px-4 pb-4 sm:px-5 sm:pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
