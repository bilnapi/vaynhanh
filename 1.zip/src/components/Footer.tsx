import React from 'react';
import { ShieldCheck, Lock, ExternalLink, Zap } from 'lucide-react';
import { LOAN_PARTNERS } from '../data/partners';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs pt-12 pb-24 md:pb-12 border-t border-slate-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <Zap className="w-5 h-5 fill-amber-300 text-amber-300" />
              </div>
              <span className="text-lg font-black text-white tracking-tight">
                Vay<span className="text-blue-500">Nhanh</span>
              </span>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded-sm bg-rose-900/60 text-rose-300 border border-rose-700/60">
                Hỗ Trợ Nợ Xấu
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Nền tảng so sánh, hỗ trợ tài chính trực tuyến và kết nối người vay có nợ xấu CIC với các đối tác tài chính uy tín, duyệt cấp tốc trong 5 phút.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-md border border-emerald-800">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Bảo Mật SSL 256-Bit</span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-blue-400 bg-blue-950/60 px-2.5 py-1 rounded-md border border-blue-800">
                <Lock className="w-3.5 h-3.5" />
                <span>Không Thu Phí Người Dùng</span>
              </div>
            </div>
          </div>

          {/* Links Col: 4 Partners */}
          <div className="md:col-span-4 space-y-2">
            <h4 className="text-xs font-extrabold text-white uppercase tracking-wider mb-2">
              Cổng Đăng Ký Trực Tiếp Đối Tác
            </h4>
            <ul className="space-y-1.5">
              {LOAN_PARTNERS.map((p) => (
                <li key={p.id}>
                  <a
                    href={p.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-blue-400 flex items-center gap-1.5 transition-colors group"
                  >
                    <span>{p.logo}</span>
                    <span className="font-semibold text-slate-300 group-hover:text-blue-400">{p.name}:</span>
                    <span className="text-slate-400 truncate">{p.tagline}</span>
                    <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-blue-400 shrink-0" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal and Disclaimer Col */}
          <div className="md:col-span-3 space-y-2">
            <h4 className="text-xs font-extrabold text-white uppercase tracking-wider mb-2">
              Thông Tin Hỗ Trợ 24/7
            </h4>
            <p className="text-xs text-slate-400">
              Tổng đài trực tuyến AI: <strong>Hoạt động 24/7</strong>
            </p>
            <p className="text-xs text-slate-400">
              Email hỗ trợ: <strong>hotro@vaynhanh.io.vn</strong>
            </p>
            <p className="text-xs text-slate-400">
              Thời gian giải ngân: <strong>Từ 3 - 15 phút qua ATM</strong>
            </p>
          </div>
        </div>

        {/* Disclaimer Note */}
        <div className="pt-6 border-t border-slate-800/80 text-[11px] text-slate-500 leading-relaxed space-y-2">
          <p>
            <strong>Tuyên bố miễn trừ trách nhiệm tài chính:</strong> VayNhanh là cổng thông tin công nghệ tài chính kết nối độc lập, hỗ trợ so sánh và giới thiệu các gói vay trực tuyến. Chúng tôi không phải là ngân hàng và không trực tiếp cho vay. Mọi quyết định phê duyệt, hạn mức, thời gian giải ngân và lãi suất được quy định bởi các đối tác cung cấp dịch vụ (MoneyCat, Vay VND, Jeff, Money Veo).
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-2">
            <span>© 2026 VayNhanh - Nền tảng hỗ trợ tài chính & nợ xấu 24/7. Bảo lưu mọi bản quyền.</span>
            <span>Chỉ dành cho công dân Việt Nam từ đủ 18 tuổi trở lên.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
