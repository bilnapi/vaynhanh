import { LoanCalculationResult, AmortizationMonth } from '../types';

export function formatVND(amount: number): string {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatNumber(amount: number): string {
  return new Intl.NumberFormat('vi-VN').format(amount);
}

export function calculateLoan({
  principal,
  months,
  annualInterestRatePercent,
  isFirstLoanPromo,
}: {
  principal: number;
  months: number;
  annualInterestRatePercent: number;
  isFirstLoanPromo: boolean;
}): LoanCalculationResult {
  // If first loan promo (0% interest for introductory period)
  if (isFirstLoanPromo) {
    const monthlyPrincipal = Math.round(principal / months);
    const schedule: AmortizationMonth[] = [];
    let remaining = principal;

    for (let m = 1; m <= months; m++) {
      const principalPortion = m === months ? remaining : monthlyPrincipal;
      remaining -= principalPortion;
      schedule.push({
        month: m,
        payment: principalPortion,
        principalPortion,
        interestPortion: 0,
        remainingBalance: Math.max(0, remaining),
      });
    }

    return {
      principal,
      months,
      annualInterestRate: 0,
      monthlyPayment: monthlyPrincipal,
      totalPayment: principal,
      totalInterest: 0,
      isFirstLoanPromo: true,
      schedule,
    };
  }

  // Standard amortized loan formula (equal monthly installments)
  const monthlyRate = (annualInterestRatePercent / 100) / 12;
  
  if (monthlyRate === 0) {
    const monthlyPayment = Math.round(principal / months);
    return {
      principal,
      months,
      annualInterestRate: 0,
      monthlyPayment,
      totalPayment: principal,
      totalInterest: 0,
      isFirstLoanPromo: false,
      schedule: [],
    };
  }

  // Formula: EMI = P * [r(1+r)^n] / [(1+r)^n - 1]
  const factor = Math.pow(1 + monthlyRate, months);
  const monthlyPayment = Math.round((principal * monthlyRate * factor) / (factor - 1));
  const totalPayment = monthlyPayment * months;
  const totalInterest = totalPayment - principal;

  const schedule: AmortizationMonth[] = [];
  let remaining = principal;

  for (let m = 1; m <= months; m++) {
    const interestPortion = Math.round(remaining * monthlyRate);
    let principalPortion = monthlyPayment - interestPortion;
    if (m === months) {
      principalPortion = remaining;
    }
    remaining -= principalPortion;

    schedule.push({
      month: m,
      payment: m === months ? (principalPortion + interestPortion) : monthlyPayment,
      principalPortion,
      interestPortion,
      remainingBalance: Math.max(0, remaining),
    });
  }

  return {
    principal,
    months,
    annualInterestRate: annualInterestRatePercent,
    monthlyPayment,
    totalPayment,
    totalInterest,
    isFirstLoanPromo: false,
    schedule,
  };
}
