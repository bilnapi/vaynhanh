import { LoanPartner } from '../types';

export const LOAN_PARTNERS: LoanPartner[] = [
  {
    id: 'moneycat',
    name: 'MoneyCat',
    officialUrl: 'https://go.3rdvn.io.vn/t/b1bb1922c3a8915d',
    logo: '🐱',
    tagline: 'Vay siêu tốc - 0% Lãi suất cho lần vay đầu',
    badge: 'Phổ biến nhất',
    minAmount: 1000000,
    maxAmount: 10000000,
    minTermDays: 91,
    maxTermDays: 182,
    interestRateText: '0% khoản vay đầu (14 ngày), sau đó 12% - 18.25%/năm',
    firstLoanPromo: 'Ưu đãi 0% lãi & phí lần đầu',
    approvalSpeed: 'Duyệt trong 5 phút',
    approvalRatePercent: 98,
    rating: 4.9,
    reviewCount: 14250,
    badDebtSupport: 'Hỗ trợ nợ xấu nhóm 1, 2, 3',
    features: [
      'Chỉ cần CCCD/CMND còn hiệu lực',
      'Không gọi thẩm định người thân hay cơ quan',
      'Tiền về thẳng tài khoản ATM trong 5 - 15 phút',
      'Độ tuổi áp dụng: 20 - 60 tuổi'
    ],
    themeColor: {
      bg: 'bg-emerald-600',
      border: 'border-emerald-200',
      text: 'text-emerald-700',
      btn: 'bg-emerald-600 hover:bg-emerald-700 text-white',
      btnHover: 'hover:bg-emerald-700',
      lightBg: 'bg-emerald-50',
    }
  },
  {
    id: 'vayvnd',
    name: 'Vay VND',
    officialUrl: 'https://go.3rdvn.io.vn/t/18b4b49f7b9fa55d',
    logo: '⚡',
    tagline: 'Giải ngân nhanh chóng - Tỷ lệ duyệt lên đến 99%',
    badge: 'Duyệt nhanh nhất (3 phút)',
    minAmount: 1000000,
    maxAmount: 15000000,
    minTermDays: 90,
    maxTermDays: 180,
    interestRateText: '0% lãi suất cho khoản vay đầu tiên trong 14 ngày',
    firstLoanPromo: '0% lãi suất cho khách hàng mới',
    approvalSpeed: 'Duyệt trong 3 phút',
    approvalRatePercent: 99,
    rating: 4.8,
    reviewCount: 9840,
    badDebtSupport: 'Hỗ trợ nợ chú ý & nợ xấu nhóm 1, 2',
    features: [
      'Xét duyệt tự động bằng công nghệ AI FinTech',
      'Nhận tiền siêu tốc qua số tài khoản ngân hàng',
      'Thủ tục hoàn toàn trực tuyến 100% không gặp mặt',
      'Bảo mật thông tin khách hàng tuyệt đối'
    ],
    themeColor: {
      bg: 'bg-blue-600',
      border: 'border-blue-200',
      text: 'text-blue-700',
      btn: 'bg-blue-600 hover:bg-blue-700 text-white',
      btnHover: 'hover:bg-blue-700',
      lightBg: 'bg-blue-50',
    }
  },
  {
    id: 'jeff',
    name: 'Jeff',
    officialUrl: 'https://go.3rdvn.io.vn/t/f101003aa09433f3',
    logo: '💎',
    tagline: 'Nền tảng so sánh & kết nối hơn 20 tổ chức tài chính',
    badge: 'Hạn mức cao tới 30tr',
    minAmount: 500000,
    maxAmount: 30000000,
    minTermDays: 90,
    maxTermDays: 365,
    interestRateText: 'Lãi suất ưu đãi từ 0% đến 18%/năm tùy đối tác',
    firstLoanPromo: 'Hạn mức linh hoạt, nhiều gói 0% lãi',
    approvalSpeed: 'Duyệt trong 5 phút',
    approvalRatePercent: 97,
    rating: 4.9,
    reviewCount: 22100,
    badDebtSupport: 'Hỗ trợ nợ xấu nhóm 1, 2, 3, 4, 5',
    features: [
      'Tự động chọn lọc gói vay nợ xấu có tỷ lệ đậu cao nhất',
      'Hạn mức mở rộng tới 30 triệu đồng',
      'Thời gian vay linh hoạt từ 3 đến 12 tháng',
      'Dễ dàng đăng ký trên mọi thiết bị di động'
    ],
    themeColor: {
      bg: 'bg-purple-600',
      border: 'border-purple-200',
      text: 'text-purple-700',
      btn: 'bg-purple-600 hover:bg-purple-700 text-white',
      btnHover: 'hover:bg-purple-700',
      lightBg: 'bg-purple-50',
    }
  },
  {
    id: 'moneyveo',
    name: 'Money Veo',
    officialUrl: 'https://go.3rdvn.io.vn/t/a27087d3b0ec5d68',
    logo: '🚀',
    tagline: 'Công nghệ FinTech số 1 - Duyệt cấp tốc 24/7',
    badge: 'Minh bạch 100%',
    minAmount: 1000000,
    maxAmount: 10000000,
    minTermDays: 91,
    maxTermDays: 182,
    interestRateText: '18.25%/năm (Ưu đãi đặc biệt khi đăng ký online)',
    firstLoanPromo: 'Hồ sơ tinh gọn chỉ 1 bước CCCD',
    approvalSpeed: 'Duyệt trong 5 phút',
    approvalRatePercent: 96,
    rating: 4.8,
    reviewCount: 8350,
    badDebtSupport: 'Hỗ trợ nợ chú ý & nợ xấu ngân hàng',
    features: [
      'Áp dụng tiêu chuẩn bảo mật quốc tế Comodo SSL',
      'Hệ thống trực tự động 24/7 kể cả nửa đêm và ngày lễ',
      'Hỗ trợ thanh toán khoản vay đa kênh tiện lợi',
      'Tư vấn và hướng dẫn tận tình chu đáo'
    ],
    themeColor: {
      bg: 'bg-amber-600',
      border: 'border-amber-200',
      text: 'text-amber-700',
      btn: 'bg-amber-600 hover:bg-amber-700 text-white',
      btnHover: 'hover:bg-amber-700',
      lightBg: 'bg-amber-50',
    }
  }
];

export const CIC_DEBT_GROUPS = [
  { group: '1', title: 'Nhóm 1: Nợ đủ tiêu chuẩn', desc: 'Quá hạn dưới 10 ngày. Duyệt 100% tại tất cả 4 đơn vị.', rate: '100%' },
  { group: '2', title: 'Nhóm 2: Nợ cần chú ý', desc: 'Quá hạn 10 - 90 ngày. Cả 4 đối tác đều hỗ trợ giải ngân ngay.', rate: '96%' },
  { group: '3', title: 'Nhóm 3: Nợ dưới tiêu chuẩn', desc: 'Quá hạn 91 - 180 ngày. Ưu tiên đăng ký Jeff và MoneyCat.', rate: '88%' },
  { group: '4', title: 'Nhóm 4: Nợ nghi ngờ', desc: 'Quá hạn 181 - 360 ngày. Jeff hỗ trợ kết nối đơn vị chuyên biệt.', rate: '82%' },
  { group: '5', title: 'Nhóm 5: Nợ có khả năng mất vốn', desc: 'Quá hạn trên 360 ngày. Jeff có giải pháp tài chính liên kết.', rate: '75%' },
];

export const LIVE_APPROVAL_NOTIFICATIONS = [
  { name: 'Nguyễn Văn T.', city: 'Hà Nội', amount: '5.000.000đ', partner: 'MoneyCat', timeAgo: 'Vừa xong' },
  { name: 'Trần Thị M.', city: 'TP. Hồ Chí Minh', amount: '10.000.000đ', partner: 'Jeff', timeAgo: '1 phút trước' },
  { name: 'Lê Hoàng P.', city: 'Đà Nẵng', amount: '3.000.000đ', partner: 'Vay VND', timeAgo: '3 phút trước' },
  { name: 'Phạm Quốc H.', city: 'Bình Dương', amount: '7.000.000đ', partner: 'Money Veo', timeAgo: '4 phút trước' },
  { name: 'Vũ Minh Đ.', city: 'Hải Phòng', amount: '15.000.000đ', partner: 'Jeff', timeAgo: '6 phút trước' },
  { name: 'Đoàn Kim O.', city: 'Cần Thơ', amount: '4.000.000đ', partner: 'MoneyCat', timeAgo: '8 phút trước' },
];
