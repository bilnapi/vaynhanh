/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { LoanPartnerList } from './components/LoanPartnerList';
import { LoanCalculator } from './components/LoanCalculator';
import { ApplicationForm } from './components/ApplicationForm';
import { RealtimeStatusTracker } from './components/RealtimeStatusTracker';
import { ChatbotAdvisor } from './components/ChatbotAdvisor';
import { CICGuideModal } from './components/CICGuideModal';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { BottomNav } from './components/BottomNav';
import { ApplicationRecord, LoanPartner } from './types';
import { MessageSquareText, Zap, ShieldAlert, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('loans');
  const [isChatbotOpen, setIsChatbotOpen] = useState<boolean>(false);
  const [isCICModalOpen, setIsCICModalOpen] = useState<boolean>(false);
  
  // Application form pre-fill states
  const [prefillAmount, setPrefillAmount] = useState<number>(5000000);
  const [prefillMonths, setPrefillMonths] = useState<number>(6);
  const [prefillPartnerId, setPrefillPartnerId] = useState<string>('moneycat');
  
  // Realtime tracked application
  const [currentApplication, setCurrentApplication] = useState<ApplicationRecord | null>(null);

  const handleSelectPartnerForApply = (partner: LoanPartner) => {
    setPrefillPartnerId(partner.id);
    setActiveTab('apply');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleApplyWithDetails = (amount: number, months: number) => {
    setPrefillAmount(amount);
    setPrefillMonths(months);
    setActiveTab('apply');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleApplicationCreated = (app: ApplicationRecord) => {
    setCurrentApplication(app);
    // Optionally switch to tracking tab after user sees success confirmation
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 pb-16 md:pb-0">
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        openChatbot={() => setIsChatbotOpen(true)}
      />

      {/* Main Content Body */}
      <main className="flex-1">
        {activeTab === 'loans' && (
          <div className="space-y-4">
            {/* Hero Section */}
            <HeroBanner
              onSelectTab={(tab) => {
                setActiveTab(tab);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onOpenCICModal={() => setIsCICModalOpen(true)}
            />

            {/* 4 Core Loan Partners */}
            <LoanPartnerList onSelectPartnerForApply={handleSelectPartnerForApply} />

            {/* Embedded Quick Calculator Section */}
            <div className="bg-white border-y border-slate-200/80 py-10">
              <LoanCalculator onApplyWithDetails={handleApplyWithDetails} />
            </div>

            {/* FAQ Section */}
            <FAQSection />
          </div>
        )}

        {activeTab === 'calculator' && (
          <div className="py-4">
            <LoanCalculator onApplyWithDetails={handleApplyWithDetails} />
          </div>
        )}

        {activeTab === 'apply' && (
          <div className="py-4">
            <ApplicationForm
              initialAmount={prefillAmount}
              initialMonths={prefillMonths}
              initialPartnerId={prefillPartnerId}
              onApplicationCreated={handleApplicationCreated}
            />
          </div>
        )}

        {activeTab === 'tracking' && (
          <div className="py-4">
            <RealtimeStatusTracker
              currentApplication={currentApplication}
              onNavigateToLoans={() => {
                setActiveTab('loans');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Sticky Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        openChatbot={() => setIsChatbotOpen(true)}
      />

      {/* Floating Chatbot Trigger for Desktop */}
      <div className="fixed bottom-6 right-6 z-40 hidden md:block">
        <button
          type="button"
          onClick={() => setIsChatbotOpen(true)}
          className="group relative flex items-center gap-2 px-4 py-3 rounded-full bg-linear-to-r from-blue-600 via-indigo-600 to-blue-700 text-white font-extrabold text-sm shadow-xl shadow-blue-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer"
        >
          <div className="relative">
            <MessageSquareText className="w-5 h-5 text-amber-300" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-blue-700 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-blue-700" />
          </div>
          <span>Tư Vấn Nợ Xấu 24/7</span>
        </button>
      </div>

      {/* Chatbot 24/7 Modal */}
      <ChatbotAdvisor
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
      />

      {/* CIC Guide Modal */}
      <CICGuideModal
        isOpen={isCICModalOpen}
        onClose={() => setIsCICModalOpen(false)}
      />
    </div>
  );
}
